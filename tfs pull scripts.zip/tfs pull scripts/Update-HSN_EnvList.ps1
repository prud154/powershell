﻿<#
.Synopsis
   Creates/Updates a .csv file which contains all the relevant information for when a file was
   migrated to any environment designated in the manifest CSV file. 
.DESCRIPTION
   Long description
.EXAMPLE
   Update-HSN_EnvList -migrateinfo <psobject>
.EXAMPLE
   Another example of how to use this cmdlet
.INPUTS
   An object with the filename, TFS Source Control location, version being migrated, and environments being migrated to
.OUTPUTS
   Updated csv file for that specific SourceControl/Filename
.NOTES
   General notes
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   HSN TFS Migration Audit
.FUNCTIONALITY
   Tracking/Auditing
#>
function Update-HSNEnvList
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Medium')]
    [OutputType([String])]
    Param
    (
        # One object representing one line from the manifest/migration.txt file
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   Position=0)]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()] 
        [psobject]$MigrateInfo
    )

Begin
  {
     Write-Host "=============================="
     Write-Host "=   Updating tracking info   ="
     Write-Host "=============================="
  }
Process
  {
    Function findline ($Environment,$SearchTrgt,$fileinfo,$log)
      {
        if ($SearchTrgt -eq "Current")
          {
            $findlinecounter = 0
            foreach ($line in $fileinfo)
              {
                if (($line.Type -eq "Current") -and ($line.TrgtEnv -eq "$($Environment)"))
                  {
                    $retval = $findlinecounter
                     "Current Line Number: $($retval)" | out-file -FilePath $log -Append
                  }
                else
                  {
                    $findlinecounter++
                  }
              }
          }
        elseif ($SearchTrgt -eq "NewHis")
          {
            $retval = "$($($($fileinfo | foreach-object {$_.Type -like "His*"} | where-object {$_ -eq $TRUE}).length))"
            $retval = 1 + $retval 
            "New History Number: $($retval)" | out-file -FilePath $log -Append
          }
        elseif ($searchTrgt -eq "PrevHis")
          {
            $findlinecounter = 0
            $prevhis = $fileinfo | where-object { ($_.Type -eq "Current") -and ($_.TrgtEnv -eq $environment) } | foreach-object { $_.Previous }
            foreach ($line in $fileinfo)
              {
                if ($prevhis -eq $line.type)  
                  {
                    $retval = "00,$($findlinecounter)"
                     "Previous History Line Number: $($retval)" | out-file -FilePath $log -Append
                  }
                $findlinecounter++
              }
            if ($retval -eq $null)
              {
                $retval = "01,No Previous History"
                 "No Previous History" | out-file -FilePath $log -Append
              }
          }
        else
          {
            $retval = "01,No Search Parameters passed to function,"
             "No Search Parameters passed to function" | out-file -FilePath $log -Append
          }
        Return $retval
      } 
      <############################# 
      End of findline 
      #############################>

      <############################## 
      Beginning of Main Section of code 
      ###############################>
    
        $fulllogpath = $($($global:HSNCRMRLoc)+"\"+$($migrateinfo.cr)+"\"+$($migrateinfo.mr)+"\RELogs\ProcessLogs\" + "UpdateEnv_"+$($migrateinfo.file)+ ".log")

        if (test-path -path $fulllogpath)
          {
            Move-Item "$fulllogpath" -destination "$($Global:HSNCRMRLoc)\$($Manifest[0].CR)\$($migrateinfo.mr)\RELogs\Processlogs\$(get-date -uformat %Y.%m.%d-%H.%M.%S)_$($fulllogpath.split("\")[-1])" | Out-Null
            New-Item -Path "$fulllogpath" -ItemType file | Out-Null
         
         
            "#############################" | out-file -FilePath "$fulllogpath" -Append
            get-date | out-file -FilePath "$fulllogpath" -Append
            "#############################" | out-file -FilePath "$fulllogpath" -Append
          }
        else
          {
            new-item $fulllogpath -ItemType File | out-null
             "#############################" | out-file -FilePath "$fulllogpath" -Append
            get-date | out-file -FilePath "$fulllogpath" -Append
             "#############################" | out-file -FilePath "$fulllogpath" -Append
          }


     $ReturnValue = $FALSE

    <#
    ////////////
    Setting up SCPATH (source control path) so it can be manipulated
    ///////////
    #>
    $LOCATION = (($migrateinfo.path).trimstart("$/")).replace("/","\")
    $Structure = [System.Collections.ArrayList]@($location.split("\"))
    
    <#
    ///////////////////////////////////////////
    Removing the Dev/Main/Release folders and the next position which is the branch name out of the SCPATH for the object passed to the cmdlet 
    ///////////////////////////////////////////
    #>

    "Original Structure: $($location)"  | out-file -FilePath $fulllogpath -Append
    if ($Structure.toupper().indexof("DEV") -gt 0)
      {
        <# $Structure.removerange($($Structure.toupper().indexof("DEV")),2) | Out-null #>
         <# 
        ////
        there are some groups who have a year folder structure within release so determining if that is the case and setting a different range for the commands below
        Given a majority of files won't have a year in them we are suppressing non-terminating errors for the duration of the check to avoid death by Red Error Msgs
        ////
        #>

        $ErrorActionPreference= "SilentlyContinue"
        [int]$Structure[($structure.toupper().indexof("DEV"))+1]
        $check = $?
        $ErrorActionPreference= "Continue"

        if ($check)
          {
            $depth = 3
          }
        else
          {
            $depth = 2
          }
        $Structure.removerange($($Structure.toupper().indexof("DEV")),$($depth)) | Out-null

      }
    elseif ($Structure.toupper().indexof("MAIN") -gt 0)
      {
        $Structure.removerange($($Structure.toupper().indexof("MAIN")),2) | Out-null

      }
    elseif ($Structure.toupper().indexof("RELEASE") -gt 0)
      {
        <# 
        ////
        there are some groups who have a year folder structure within release so determining if that is the case and setting a different range for the commands below
        Given a majority of files won't have a year in them we are suppressing non-terminating errors for the duration of the check to avoid death by Red Error Msgs
        ////
        #>

        $ErrorActionPreference= "SilentlyContinue"
        [int]$Structure[($structure.toupper().indexof("RELEASE"))+1]
        $check = $?
        $ErrorActionPreference= "Continue"

        if ($check)
          {
            $depth = 3
          }
        else
          {
            $depth = 2
          }
        $Structure.removerange($($Structure.toupper().indexof("RELEASE")),$($depth)) | Out-null
      }
    else <# Very Very Very unlikely but just in case #>
      {
             "NO Dev, Main, or Release branch discovered in path for $($migrateinfo.path)" | Out-file -FilePath $fulllogpath -Append
             "" | Out-File -FilePath $fulllogpath -Append
      }

    <#
    ///////////////////////////////////////////
    Verify and Create directory structure which mimics the path in TFS based on the modified SCPATH (see above) for the object passed
    //////////////////////////////////////////
    #>
    
    $fullpath = $($global:HSNEnvLoc)

    <# Rebuilding the path from the array $structure to be used to see if the tracking file already exists #>

    foreach ($dir in $structure)
      {
        $fullpath = $($fullpath +"\"+ $dir)
      }
     "New folder structure: $($fullpath)" | out-file -FilePath $fulllogpath -Append
     $fullpath = $($fullpath + "\" + $($migrateinfo.file) + ".csv")

    if (test-path -Path $($fullpath))
      {
         "CSV tracking file exists" | out-file -FilePath $fulllogpath -Append
      }
    else 
      {
        <# 
        ////////////////////////////
        creating directory structure based on the TFS path (minus the dev/main/release folders) @ \\filer01\miscommon$\cm share\release engineers\tfsenvino\ 
        ////////////////////////////
        #>
        $path = $global:HSNEnvLoc

        foreach ($item in $Structure)
        {
          if (!(test-path -Path "$path\$item"))
            {
              new-item -Path "$path\$item" -ItemType Directory | out-null
              $path = $path+"\"+$item
            }
          else
            {
              $path = $path+"\"+$item
            }
        }
        copy-item -path "$global:HSNEnvLoc\template.csv" -Destination "$fullpath" | out-null
      }

    <# 
    ////////////////////////////////////
    Open csv environent file, read contents, modify contents, write contents back out
    ///////////////////////////////////////
    #>
    $filedata=@()
    $filedata+=import-csv -Path "$fullpath"
    
    $envlabels = ($migrateinfo.TrgtEnv).split(";")
    
    foreach ($specificenv in $envlabels)
      {
        if (!($filedata | where-object {($_.TrgtEnv -eq "$specificenv") -and ($_.Type -eq "Current")}))
          {
        <# 
        /////////////////////////////
        This if statement covers the addition of a new Environment to a tracking file 
        ////////////////////////////
        #>

            $adddata = new-object -typename PSObject -property @{
              Type = "Current"
              TrgtEnv = $specificenv
              PullDate = $(get-date -format g)
              CR = $migrateinfo.CR
              MR = $migrateinfo.mr
              ChgSet = $migrateinfo.ChgSet
              RE = [environment]::UserName
              Path = $migrateinfo.path
              Notes = "Initial Entry"
              Previous="NA"
              }
            $addData | export-csv -path $fullpath -NoTypeInformation -append
             "New Environment --> $($specificenv) added to tracking sheet" | out-file -FilePath $fulllogpath -append
          }
       else
           {
        <#
        //////////////
        This Else statement is where a majority of the data flowing through this cmdlet will go through. This section updates existing data
        /////////////
        #>
           $currentlinenum = findline -Environment $specificenv -SearchTrgt "Current" -fileinfo $filedata -log $fulllogpath
           $newhisnum = findline -Environment $specificenv -SearchTrgt "NewHis" -fileinfo $filedata -log $fulllogpath
           $prevhisnum = findline -Environment $specificenv -SearchTrgt "PrevHis" -fileinfo $filedata -log $fulllogpath

             <# 
             /////////////
             Standard procedure for most changes 
             ////////////
             #>
               <#
               ///////
               move current info to history item
               //////
               #>
                $newhisobject = New-object PSObject -property @{
                Type = "His-"+$($newhisnum)
                TrgtEnv = $($filedata[$($currentlinenum)].TrgtEnv)
                PullDate = $($filedata[$($currentlinenum)].PullDate)
                CR = $($filedata[$($currentlinenum)].CR)
                MR = $($filedata[$($currentlinenum)].MR)
                ChgSet = $($filedata[$($currentlinenum)].ChgSet)
                RE = $($filedata[$($currentlinenum)].RE)
                Path = $($filedata[$($currentlinenum)].Path)
                Notes = $($filedata[$currentlinenum].notes)
                Previous=$($filedata[$($currentlinenum)].Previous)
                }

               $filedata = $filedata + $newhisobject
               <#
               //////
               Move migrateinfo info into current data 
               /////
               #>
               $filedata[$($currentlinenum)].PullDate = $(get-date -format g)
               $filedata[$($currentlinenum)].CR = $($migrateinfo.CR)
               $filedata[$($currentlinenum)].MR = $($migrateinfo.MR)
               $filedata[$($currentlinenum)].RE = $($env:username)
               $filedata[$($currentlinenum)].ChgSet = $($migrateinfo.ChgSet)
               $filedata[$($currentlinenum)].Previous = $("His-"+$($newhisnum))
               $filedata[$($currentlinenum)].Notes = ""
               $filedata[$($currentlinenum)].Path = $($migrateinfo.path)

                "New Current: $($filedata[$currentlinenum])" | out-file -FilePath $fulllogpath -Append
                "New History: $($filedata | where-object { $_.type -eq $("His-"+$($newhisnum)) })" | out-file -FilePath $fulllogpath -Append
            $filedata | export-csv -Path "$fullpath" -NoTypeInformation
            if ($?)
                {
                $UpdateIssue = $FALSE
                }
            else
                {
                $UpdataIssue = $TRUE
                }
            }

       }
     }
End
  {
    return $UpdateIssues
  }
}
<# ////// End of Update-HSN_EnvList.ps1 ////// #>