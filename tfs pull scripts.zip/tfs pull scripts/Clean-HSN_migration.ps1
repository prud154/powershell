﻿<#
.Synopsis
   Cleans the migration file for common mistakes and common extra characters. 
.DESCRIPTION
    Removes tabs, leading and trailing spaces, blank lines, and converts all / to \ (this is the TFS syntax and should work for pvcs as well). 
        NOTE: We can't convert the main lines of the migration.txt to lower or upper do to Unix's case sensitivity. 
    Checks to make sure all version/changeset items are of the proper syntax. 
    Checks that all paths's end in a filename (aka the last character isn't a /). 
    (added 12/23/14 - Trey) Checks that the environment labels specified are valid and in upper case 

    
    Important NOTE: This is the component which makes the CR/MR a globally defined variable. It isn't defined till this runs. Although the intent this is the 2nd or third component to run in the process. 

    Future: May add additional parameters at the end to designate type of migration and any other 

.EXAMPLE
   Clean-HSN_MigrationFile -Path <[string] path to file to be cleaned up>. The path can come from the pipe or passed on the command line
.INPUTS
   [String] Path to file to be processed/cleaned
.OUTPUTS
   [string] object including cr, mr, path, filename, version/changeset
.NOTES
   General notes
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   The functionality that best describes this cmdlet
#>
function Clean-HSN_MigrationFile
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$true,
                  ConfirmImpact='Medium')]
    [OutputType([String])]
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true
        )]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("Location")] 
        [string]$Path
    )
    Begin
    {
    Write-Host "============================"
    Write-Host "=  Cleaning Migration.txt  ="
    Write-Host "============================"
    }
    Process
    {

    <# Declaring Variables #>

         if ($ErrorMsgs -ne $null)
           {
             remove-variable errors
           }

         if ($warnings -ne $null)
           {
             remove-variable warnings
           }
         <#
         //////////////////////////////////////////////
         Getting original migration.txt file and converting the excel special character to <special> and any TAB to <tab> so it is easier to see in notepad
         ///////////////////////////////////////////////
         #>

         $original = (get-content -path "$Path")

         Create-HSN_CRMRLoc -CR $original[0] -MR $original[1]

         <#//////////////////////////////////////////////////
         1st replace = converts any tabs (`t=tabs) to spaces 
         2nd Replace = converts \ to / (tfs syntax and consistency in further process steps)
         trimend = trailing spaces
         trimstart = leading spaces
         where {$_}=removes blank lines
         Then pipe the resulting migration.txt contents into a String array called "Item"
         ///////////////////////////////////////////////////////
         #>
         $item = (((((((((get-content -Path "$Path")).replace(" ",">>EXCEL<<")).replace("`t"," ")).replace("\","/")).trimend(" ")).trimstart(" "))))

         if ($original -ne $item)
           {
           $Warnings = $Warnings + "common typos fixed (tabs,starting/trailing spaces,\ to /,"
           }
         
         <# converting environment labels to UPPER Case for downstream processing #>
         $item[2] = $item[2].toupper()
         $envlabels = $item[2].split(",")
         
         <### This section of code is to catch if someone puts PROD instead of PRD in for Production. Will convert it to PRD ##>
         $envlabelcount = 0
         foreach ($label in $envlabels) <# given there can be multiple environments listed have to loop through all possibilities. If there is only one then the default is the 0 position #>
           {
             If ($label -eq "PROD")
               {
                 $envlabels[$($envlabelcount)] = "PRD"
               }
             $envlabelcount++
           }
         remove-variable envlabelcount
         <##### END of PROD Catch Section #####>

         $LegalLabels = $(get-content -Path ($GLOBAL:HSNCRMRLoc + "\LegalLabels.csv")).split(",")
         $badlabels = [System.Collections.ArrayList]@()
         $envlabels | Where-Object {$_ -notin $($LegalLabels)} | foreach {$badlabels.add($_)}

         if ($badlabels -ne $null)
           {
             $ErrorMsgs = $ErrorMsgs + "Invalid Environment Labels: $Badlabels,"
             $CleanError = $TRUE
           }
         
         <# Removing all lines not starting with $/ #>
         $counter=4
         $numlinesdeleted=0
                  
         foreach ($line in $item[3..($item.length)])
         {
           If (!($line.startswith("$/")))
             {
               $warnings = $Warnings + "Line: $counter was removed from migration.txt,"
               $CleanWarning = $TRUE
               $item[$counter-1]=$null
             }
            
           elseif ($line -match ">>EXCEL<<")
             {
               <# 
               ///////////////////////////////////////////
               A special character (looks like a space but isn't) is sometimes copied from an Excel file and we haven't found a way to remove it with Powershell. Till we can a warning is being generated
               ///////////////////////////////////////////
               #>
               $ErrorMsgs = $ErrorMsgs + "Line $($counter) : Special Excel Character exists,"  
               $CleanError = $TRUE
             }
           else
             {
               <# Cleaning up some of the more odd occurences #>
               $tempVer=$(($line.split(" "))[-1]) <# Getting Version number off of the line. Split all <spaces> and then assuming there is at least one space in front of version then the last position of the array (-1) is the version  #>
               $SCver=$($tempver.trimend(" ")).trimstart(" ") <# trimming all spaces around the version number #>
               $temppath=($line.trimend("$tempver")).trimend(" ") <# creating tempvariable to split the path from the filename but first removing the version from the line #>
               $tempfile=((($temppath.split("/"))[-1])) <# Pulling the filename off of the line by splitting at all / #> 
               $SCfile=$($tempfile.trimend(" ")).trimstart(" ") <# removing all spaces around the filename  #>
               <# $temppath=$($temppath.trimend($tempfile)) <# removing the filename off of the path #> #>
               $SCpath=$($($temppath.trimend($tempfile)).trimend(" ")) <# Removing trailing spaces.  #>
               $item[$counter-1]=$SCpath+$SCfile+" "+$SCver
               <# removing variables from memory to better ensure no bleeding of information between runs/lines #>
               remove-variable scver
               remove-variable temppath
               remove-variable tempfile
               remove-variable scfile
               remove-variable scpath

               if ($line.StartsWith("`$/"))
                 {
                   try
                     { <# splits on the first space from the end of the line and tries to set the result to an numeric field type. This will fail if there are any alpha char in the check (other than . or more than one .)#>
                       [decimal]$var = ($line.split(" "))[-1]
                     }
                   catch
                     {
                       $ErrorMsgs = $ErrorMsgs + "Line: $($Counter) - TFS Invalid Changeset number specified,"
                       $CleanError = $TRUE
                     }
                 }
                
               <# 
               Determining if the end of the TFS path is a filename. Basically the last character isn't a / 
               This is based on the assumption only one " " in between last character of path and the start of the version/changeset #
               checking for a filename extension (.xxx) isn't valid as there are several files which don't have extensions (WMS's RF for example)
               There will be a seperate module later in the process to check to see if the filename exists or not
               #>
               $tempchararray = [char[]](($line.split(" ")[-2]))
               if ($tempchararray[-1] -eq "/")
                 {
                   $ErrorMsgs = $ErrorMsgs + "Line: $($counter) - Missing filename,"
                   $CleanError = $TRUE
                   $tempchararray=@() <# clearing char array for next pass #>
                 }

            }
           ++$counter
         } <# end of For Loop #>

        $item=$item | where-object {$_} <# clearing any created blank lines in the migration.txt #>

        $log = "$global:HSNCRMRLoc"+"\$($item[0])"+"\$($item[1])"+"\RELogs\ProcessLogs\Clean-HSN_migration.log"


         if (!(test-path $($log)))
           {
             New-Item -Path "$log" -itemtype File | out-null
              "" | out-file -FilePath $log -Append
              "*********************************" | out-file -FilePath $log -Append
              " $(get-date) " | out-file -FilePath $log -Append 
              "*********************************" | out-file -FilePath $log -Append 
           }
         else
           {
             Move-Item "$log" -destination "$($Global:HSNCRMRLoc)\$($Original[0])\$($original[1])\RELogs\ProcessLogs\$(get-date -uformat %Y.%m.%d-%H.%M.%S)_$($Log.split("\")[-1])" | Out-Null
             New-Item -Path "$log" -ItemType file | Out-Null
             
             
              "" | out-file -FilePath $log -Append
              "*********************************" | out-file -FilePath $log -Append
              " $(get-date) " | out-file -FilePath $log -Append 
              "*********************************" | out-file -FilePath $log -Append 
           }
        
         "" | out-file -FilePath $log -append
         "Migration.txt Issues for $(get-date)" | out-file -FilePath $log -append
         "===========================================" | out-file -FilePath $log -append
         ""  | out-file -FilePath $log -append
         "Warnings"  | out-file -FilePath $log -append
         "========"  | out-file -FilePath $log -append
        if ($warnings -eq $null)
          {
             "No Warnings" | out-file -FilePath $log -append
          }
        else
          {
             $($Warnings.split(",")) |  out-file -FilePath $log -append
          }
         "" | out-file -FilePath $log -append
         "Errors:" | out-file -FilePath $log -append
         "========" | out-file -FilePath $log -append
        if ($ErrorMsgs -eq $null)
          {
             "No Errors" | out-file -FilePath $log -append
          }
        else
          {
             "$($ErrorMsgs.split(","))" | out-file -FilePath $log -append
          }
        
        "" | out-file -FilePath $log -append
        "" | out-file -FilePath $log -append
        "Original Migration.txt" | out-file -FilePath $log -append
        "=======================" | out-file -FilePath $log -append
        $original | out-file -FilePath $log -append
        "" | out-file -FilePath $log -append
        "" | out-file -FilePath $log -append
        "Migration.txt with proposed changes"  | out-file -FilePath $log -append
        "=======================" | out-file -FilePath $log -append
        $item | out-file -FilePath $log -append
        "" | out-file -FilePath $log -append

        <# Writting modified migration.txt to CR/MR folder #>

        $newmigrationtxt = $($global:HSNCRMRLoc+"\"+$($item[0])+"\"+$($item[1])+"\"+$($path.split("\")[-1]))
         
        if (test-path $($newmigrationtxt))
          {
             Move-item -Path $newmigrationtxt -Destination $($global:HSNCRMRLoc+"\"+$($item[0])+"\"+$($item[1])+"\RELogs\OldLogs\"+($($path.split("\")[-1]).trimend(".txt"))+"_"+$(get-date -uformat %Y.%m.%d-%H.%M.%S)+".txt")
          }
    
        $item | out-file -filepath "$newmigrationtxt" -noclobber


} <# End of Process Block #>
    End
    {
      return ($CleanError,$CleanWarning,$NewMigrationTxt)
    }
}