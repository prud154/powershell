﻿;<#
.Synopsis
   Perform standard verification tests for items coming out of TFS
.DESCRIPTION
   Based on the manifest in the appropriate CR/MR folder this script will go through all TFS items to do standard verification tests before anything is pulled from TFS for deployment: 
   1)   Does the changeset exists?
        NOTE: using the powertools get-changeset command do you get a result?
   4)	Is the file in the changeset?
        NOTE: using get-changeset scan the results to see if the filename shows up
   2)	Is path given in the MR actually the path in TFS?
        NOTE: This check is against the path of the file in the changeset is the actual path in TFS versus the path given in the MR
   5)	If coming from DEV branch throw warning as this needs to be confirmed as we don't normally deploy from DEV
   6)	Is file/changeset already in the target environment?
        NOTE: There is an outside dependency which has to be met first before this verification test can be performed. Skip for now
   7)	Is there a newer changeset for file on branch
        NOTE: Get all changesets for a path/file and see if there is a higher changeset number than the one provided in the MR

   The -file option will cause the script to prompt for the location of the manifest file to be used for processing. If not provided the script will assume the data is coming directly from a piped object. 

   The -TFSTest option sets the TFS server to the Test environment and is hard coded to use the RE Test collection. 

   The -digital option sets the TFS server to the Digital Production TFS Collection. There is no Digital Test instance. 

.EXAMPLE
   Verify-HSN_SCFiles -file
.EXAMPLE
   Verify-HSN_SCFiles -file -TFSTest
.INPUTS
   [switch] -file = Lets the program know if a file path/name dialog box needs to be presented to the user. 
   [switch] -TFSTest = Sets the TFS server instance to the Test environment and is hard coded to go to the RE collection. 
.OUTPUTS
   [ascii txt file] RELogs folder in the CR/MR folder by the name of Verify-HSN_SCFiles_<date/time>.log
.NOTES
   Requires that the proper version of the TFS Powertools be installed on the system the script is running from. 
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   Performs verification tests of files planned on being pulled from TFS. 
#>
function Verify-HSN_SCFiles
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Low')]
    [OutputType([String])]
    Param
    (
        # Param1 help description
        [Parameter(ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   ValueFromRemainingArguments=$false, 
                   Position=0
                  )]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string[]]$Manifestloc,
        
        # Switches the TFS Server to the digital collection
        [Parameter()]
        [AllowNull()]
        [switch]
        $Digital,

        # Switches the TFS server instance to the Test environment. Hard coded to the RE Test area. 
        [Parameter()]
        [AllowNull()]
        [switch]
        $TFSTest,

        # Causes a file path/name dialog box to be presented for the select of the manifest file to be processed. 
        [Parameter()]
        [AllowNull()]
        [switch]
        $file,

        # Switches the TFS server instance to the Test environment. Hard coded to the RE Test area. 
        [Parameter()]
        [AllowNull()]
        [switch]
        $CRReview
    )
Begin
{
<# 
Setting TFS Server location .. Used by the various TFS Utilities 
#>
      $TFSServerURL="http://tfs.hsn.net:8080/tfs/DefaultCollection/" <# Production TFS Instance #>



    Write-host "==============================================`n"
    Write-Host "==  Starting validation of manifest entries ==`n"
    Write-host "==============================================`n"

    <# 
    Detecting if Powertools are installed. If they are not then a lot of the following script will fail!
    #>
    if ($env:TFSPowerToolDir -eq $null)
    {
         "The TFS Powertools are not installed on this machine`n" | out-file -FilePath "c:\temp\error.txt" -Append
        $ErrorMSG = $TRUE
    }
    else
    {
        try
        {
            Add-PSSnapin Microsoft.teamfoundation.powershell -ErrorAction Stop
        }
        catch
        {
            [System.Management.Automation.Runspaces.PSSnapInException]
             "The TFS Powertools are not installed on this machine`n" | out-file -FilePath "c:\temp\error.txt" -Append
            $ErrorMSG = $TRUE
        }
    }

        $TFSServerObject = get-tfsserver -name "$TFSServerURL" 
} # End of Begin section
Process
{

if ($manifestLOC -eq $null)
  {
    $Manifest = Import-csv -Path (Get-HSN_FileLoc -WindowTitle "Select the Manifest CSV file you wish to process" -InitialDirectory "$global:HSNCRMRLoc")
  }
else
  {
    $Manifest = Import-csv -path "$Manifestloc"
  }

Create-HSN_CRMRLoc -CR $manifest[0].CR -MR $manifest[0].MR

<# Setting up Logging files. "$goodlog" = positive results and "$badlog" = Failures during verification #>

<# $goodlog = ($global:HSNCRMRLoc+"\"+$($manifest[0].cr)+ "\"+ $($manifest[0].MR)+"\RELogs\ProcessLogs\Verify-GOODFILES.log")

if (!(test-path -Path "$goodlog"))
  {
    new-item -Path "$goodlog" -ItemType File | out-null
     "" | Out-File -FilePath "$goodlog" -append
     "***************************" | Out-File -FilePath "$goodlog" -append
     " $(get-date) " | Out-File -FilePath "$goodlog" -append
     "***************************" | Out-File -FilePath "$goodlog" -append
     "" | Out-File -FilePath "$goodlog" -append
  }
Else
  {
     
     Move-Item "$GoodLog" -destination "$($Global:HSNCRMRLoc)\$($manifest[0].CR)\$($manifest[0].MR)\RELogs\ProcessLogs\$(get-date -uformat %Y.%m.%d-%H.%M.%S)_$($GoodLog.split("\")[-1])" | Out-Null
     New-Item -Path "$GoodLog" -ItemType file | Out-Null
     
     "" | Out-File -FilePath "$goodlog" -append
     "***************************" | Out-File -FilePath "$goodlog" -append
     " $(get-date) " | Out-File -FilePath "$goodlog" -append
     "***************************" | Out-File -FilePath "$goodlog" -append
     "" | Out-File -FilePath "$goodlog" -append
  }
#>
$badlog = ($global:HSNCRMRLoc+"\"+$($manifest[0].cr)+ "\"+ $($Manifest[0].MR)+"\RELogs\ProcessLogs\Verification.log")

if (!(test-path -Path "$BadLog"))
  {
    new-item -Path "$BadLog" -ItemType File | out-null
     "" | Out-File -FilePath "$BadLog" -append
     "***************************" | Out-File -FilePath "$BadLog" -append
     " $(get-date) " | Out-File -FilePath "$BadLog" -append
     "***************************" | Out-File -FilePath "$BadLog" -append
     "" | Out-File -FilePath "$BadLog" -append
  }
Else
  {
     
     Move-Item "$BadLog" -destination "$($Global:HSNCRMRLoc)\$($Manifest[0].CR)\$($Manifest[0].MR)\RELogs\ProcessLogs\$(get-date -uformat %Y.%m.%d-%H.%M.%S)_$($BadLog.split("\")[-1])" | Out-Null
     New-Item -Path "$BadLog" -ItemType file | Out-Null
     
     "" | Out-File -FilePath "$BadLog" -append
     "***************************" | Out-File -FilePath "$BadLog" -append
     " $(get-date) " | Out-File -FilePath "$BadLog" -append
     "***************************" | Out-File -FilePath "$BadLog" -append
     "" | Out-File -FilePath "$BadLog" -append
  }

<#
Creating an object which contains the manifest of items to be processed. If the parameter of -file is passed the user will be prompted for the 
manifest location (in the event there is a significant time delay needed between creating the manifest file and pulling the files from source control tool). 
Otherwise the program assumes the manifest is coming from a piped object. The most natural assumption the piped object is coming from create-HSN_manifest but can be 
from any other program as long as it follows the same manifest structure. 
#>


<#
====================================================================
Main Processing block -- All data is held in variables. The next big segment is for writting the data to the files
====================================================================
#>

<# Creating arrays directly as I need to create them as System.Array versus System.Object to enable better add/removal features than the standard array created by Powershell #>
$TFS_CS_List = @(([string]($manifest | foreach-object {$_.ChgSet } | Sort-object -Unique)).split(" "))
$WARNING_DevInManifest = @($manifest | where-object {$_.path -like "*/Dev/*"} | foreach-object {$_.path+"/"+$_.file})

$ERROR_CSDoesntExist =  [System.Collections.ArrayList]@()
$WARNING_CSBasedOffDevBranch = [System.Collections.ArrayList]@()
$ERROR_notinchangeset = [System.Collections.ArrayList]@()
$PASS_inchangeset = [System.Collections.ArrayList]@()
$ERROR_typos = [System.Collections.ArrayList]@()
$ERROR_typosMaybe = [System.Collections.ArrayList]@()
$ERROR_badchangeset = [System.Collections.ArrayList]@()
$ERROR_badchangesetMaybe = [System.Collections.ArrayList]@()
$ERROR_NotLatestChangeset = [System.Collections.ArrayList]@()
$ERROR_NotLatestChangesetMaybe = [System.Collections.ArrayList]@()
$ERROR_BADBRANCH_Main = [System.Collections.ArrayList]@()
$ERROR_BADBRANCH_REL = [System.Collections.ArrayList]@()
$ERROR_BADBRANCH_RTP = [System.Collections.ArrayList]@()
$ALREADY_DEPLOYED = [System.Collections.ArrayList]@()
$temp_FAIL_array = [System.Collections.ArrayList]@() <# used to contain the items not in the changeset being processed  #>
$temp_PASS_Array = [System.Collections.ArrayList]@() <# used to contain the items in the changeset for further processing  #>
$EnvInfo_GOOD = [System.Collections.ArrayList]@()
$EnvInfo_WARNING = [System.Collections.ArrayList]@()
$EnvInfo_ERROR = [System.Collections.ArrayList]@()
<#
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Getting information on the changeset and validating if it exists in TFS if not pull from changeset list to minimize further processing
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#>

Foreach ($ChangeNum in $TFS_CS_List)
  {
    $CheckNotInChangeset = $FALSE <# clearing out for each pass through loop #>
    $checkInChangeset = $FALSE <# clearing out for each pass through loop #>

    <#
    ////////////////////////////////////////
    Pulling contents of changeset into a variable for processing. 
    If changeset doesn't exist then result is $null and then the process will check to see if the path is legit and if so provide the latest changeset number for that path
    ///////////////////////////////////////
    #>
    $CS_FILE_LIST = ((Get-TfsChangeset -ChangesetNumber $changenum -Server $tfsserverobject) | foreach-object {$_.changes} | foreach-object {$_.item.serveritem})
    $tmpmanifest = $manifest | where-object {$_.chgSet -eq $($changenum)}

    if ($CS_FILE_LIST -eq $null)
      {
        $Error_CSDoesntExist.add($changenum) | Out-Null
      }
        <#
        /////////////////////////////////////////////////////
        Parsing each object in the Manifest and checks to see if it is in the specific changeset being processed in this loop. 
        The check has to be a perfect match between the path in TFS and the path provided in the migration.txt. They will be off either due to one or more of the following conditions:
        1) Typo in the path provided in the migration.txt (Migration.txt has the word --> TEST <--- but was checked into TFS as --> TST <---
        2) Typo in the changeset identified for the file (Migration.txt has the changeset --> 10759 <-- but the actual changeset number is --> 10795 <---
        3) File isn't in the changeset # provided in the migration.txt (Migration.txt has the changeset --> 10759 <-- but actually is in --> 20345 <----
        4) File was checked into a different folder than what was documented in the migration.txt (there is no easy check for this without scanning the entire TFS hiearchy)
            NOTE: This will be caught though indirectly because the path in the changeset won't match the path given in the migration.txt file. 
        ////////////////////////////////////////////////////
        #>

    Foreach ($item in $tmpmanifest)
        {
            $temp_FAIL_array = [System.Collections.ArrayList]@() <# used to contain the items not in the changeset being processed  #>
            $temp_PASS_Array = [System.Collections.ArrayList]@() <# used to contain the items in the changeset for further processing  #>

            if ($CS_FILE_LIST -notcontains $($item.path+"/"+$item.File))
            {
                $ERROR_notinchangeset.add("$($item.path +"/"+$item.File+" "+$item.ChgSet)") <# Master list of items not in the designated changeset #> | out-null
                $temp_FAIL_Array.add("$($item.path +"/"+$item.File+" "+$item.ChgSet)") <# Adding to this array so we don't reprocess items per loop #> | out-null
                $CheckNotInChangeset = $true <# Setting flag to do check of bad items to see if it is due to a typo or some other checkable attribute #>
             }
            else
            {
                $PASS_inchangeset.add("$($item.path +"/"+$item.File+" "+$item.ChgSet)") | out-null  <# Master list of items not in the designated changeset #>
                $temp_PASS_Array.add("$($item.path +"/"+$item.File+" "+$item.ChgSet)") | out-null  <# Adding to this array so we don't reprocess items per loop #>
                $CheckInChangeset = $true <# Setting flag to do check to ensure specified changeset is the latest changeset #>
             }
        
        <# ////////////////////////////////////////////////////////
        Validating the branch identfied in the path statement of the file is the branch it should be on based on the identified environment(s) in the manifest. 

        NOTE: This is based on the assumption each environment originally identified in the migration starts with the respective template
        Development Enviroment = Label starting with a "D"
        QA Environment = Label starting with a "Q"
        UAT Environment = Label starting witha "U"
        Training/Beta Environment = Label starting with a "T"
        PRODuction Environment = Label starting with a "P"
        ///////////////////////////////////////////////////////////
        #>
        
            $LABELS = (($item.TrgtEnv).split(";"))
            <#The following line will "filter" out multiple D,Q,U,T,P labels into a generic $ENV lable of TRUE/FALSE if that env label appears even once #>
            $LABELS | foreach {If ($_ -like "Q*"){$QA=$TRUE}elseif($_ -like "U*"){$UAT = $TRUE}elseif($_ -like "P*"){$PROD=$TRUE}elseif ($_ -like "T*"){$TRN=$TRUE}elseif($_ -like "D*"){$DEV=$TRUE}}

        <# 
        //////////////////////////////////////////////////////
        Processing the good items to make sure the changeset is the latest changeset. 
        /////////////////////////////////////////////////////////
        #>

        If ($checkInChangeset) 
          {
            foreach ($tmpvar in $temp_PASS_Array)
              {
                $Ver=$(($tmpvar.split(" "))[-1])
                $Path = $($tmpvar.trimend("$Ver")).trimend(" ")
                $lastver = $(get-tfsitemhistory -HistoryItem "$path" -server $tfsserverobject).changesetid[0]
                if ($ver -ne $lastver)
                  {
                    $PASS_inchangeset.remove("$tmpvar") | out-null
                    $ERROR_NotLatestChangeset.add("$tmpvar") | out-null
                    $ERROR_NotLatestChangesetMaybe.add("$lastver") | out-null
                  }

                <# INSERT SECTION FOR CHECKING IF FILE IS ALREADY IN THE ENVIRONMENT #>
                $ENVLOCATION = (($path).trimstart("$/")).replace("/","\")
                $Structure = [System.Collections.ArrayList]@($ENVLOCATION.split("\")) <# Splitting the path based on \ so we can remove the dev/main/release and subsequent dir from the path. This matches the path for the location of the env tracking files #>
            
                if ($Structure.toupper().indexof("DEV") -gt 0)
                <# Some groups have distinct DEV branches for each initiative. This is to catch those and strip the path from the DEV folder down to the DEV branch name #>
                  {
                     $ErrorActionPreference= "SilentlyContinue"
                    [int]$Structure[($structure.toupper().indexof("DEV"))+1]
                    $check = $?
                    $ErrorActionPreference= "Continue"

                    if ($check)
                      {
                        $depth = 3
                      }
                    else
                      {
                        $depth = 2
                      }
                    $Structure.removerange($($Structure.toupper().indexof("DEV")),$($depth)) | out-null
                  }
                elseif ($Structure.toupper().indexof("MAIN") -gt 0)
                  {
                    $Structure.removerange($($Structure.toupper().indexof("MAIN")),2) | out-null
                  }
                elseif ($Structure.toupper().indexof("RELEASE") -gt 0)
                  {
                    <# 
                    ////
                    there are some groups who have a year folder structure within release so determining if that is the case and setting a different range for the commands below
                    Given a majority of files won't have a year in them we are suppressing non-terminating errors for the duration of the check to avoid death by Red Error Msgs
                    ////
                    #>

                    $ErrorActionPreference= "SilentlyContinue"
                    [int]$Structure[($structure.toupper().indexof("RELEASE"))+1]
                    $check = $?
                    $ErrorActionPreference= "Continue"

                    if ($check)
                      {
                        $depth = 3
                      }
                    else
                      {
                        $depth = 2
                      }
                    $Structure.removerange($($Structure.toupper().indexof("RELEASE")),$($depth)) | out-null
                  }
                else <# Very Very Very unlikely but just in case #>
                  {
                     "CRITICAL: NO Dev, Main, or Release branch discovered in path for $($tmpvar)" | Out-File -FilePath "$badlog" -Append
                     "" | Out-File -FilePath "$badlog" -Append
                    $GLOBAL:ENVUpdateissue=$true
                  }

                $envinfopath = $($global:HSNEnvLoc)

                foreach ($dir in $structure) <# Rebuilding path for use in calls #>
                  {
                   $envinfopath = $($envinfopath +"\"+ $dir)
                  }

              <#  if (!(test-path -path $($envinfopath + ".csv")))
                  {
                    $EnvInfo_WARNING.add("First Deploy from TFS: $($tmpvar)`n") | out-null
                  }
              #>
              If (!(test-path "$($envinfopath+".csv")"))
              {
                "No environment info to compare with so everything passes"
              }
              else
              {
                    $envinfo = import-csv -Path "$($envinfopath+".csv")"

                    foreach ($TrgtEnv in $labels)
                      {
                        $currentver = $envinfo | where-object {$_.type -eq "Current"} | where-object {$_.TrgtEnv -eq $TrgtEnv}

                        If ($currentver.ChgSet -lt $Ver)
                          {
                            if ($CRReview)
                              {
                                $EverInEnv = $envinfo | where-object {($_.TrgtEnv -eq $TrgtEnv) -and ($_.ChgSet -eq $Ver)}

                                if ($EverInEnv -eq $null)
                                  {
                                    $EnvInfo_ERROR.add("Never Migrated to $TrgtEnv : $($tmpvar)`n") | out-null
                                  }
                                else
                                  {
                                    $EnvInfo_WARNING.add("Has been but is not currently (Current is $($currentver.ChgSet)) in $TrgtEnv : $($tmpvar)`n") | out-null
                                  }
                              }
                            else
                              {
                                $EnvInfo_GOOD.add("$($tmpvar)`n") | out-null
                              }
                          }
                        elseif ($currentver.ChgSet -eq $ver)
                          {
                            if ($CRReview)
                              { 
                                $EnvInfo_GOOD.add("Currently in $TrgtEnv : $($tmpvar)`n") | out-null
                              }
                          }
                        elseif ($currentver.ChgSet -gt $Ver)
                          {
                            if ($CRReview)
                              {
                                $EverInEnv = $envinfo | where-object {($_.TrgtEnv -eq $TrgtEnv) -and ($_.ChgSet -eq $Ver)}

                                if ($EverInEnv -eq $null)
                                  {
                                    $EnvInfo_WARNING.add("Clean Up Branch? - Newer Version -> $($currentver.ChgSet) <- in $TrgtEnv than what was requested: $($tmpvar)`n") | out-null
                                  }
                                else
                                  {
                                    $EnvInfo_WARNING.add("Has been but is not currently (Current is $($currentver.ChgSet)) in $TrgtEnv : $($tmpvar)`n") | out-null
                                  }
                              }
                          }
                      }
                    }
             }
          }
        <# //////////////////////////////////////////////////////////////////
        Checking all the bad items and splitting them into typos in the path given to us or the wrong changeset was specified
        As possible, we query the system to see if we can find the correct path / changeset. If a suggestion is possible it is given in the log. 
        /////////////////////////////////////////////////////////////////////
        #>
        If ($CheckNotInChangeset)
            {
        foreach ($item in $temp_FAIL_array) <# temp_array is the bad array for the specific changeset being processed in this loop and not the entire "bad" list #>
         {
           $itempath = $item.trimend("$($item.split(" ")[-1])") <# first determining the version and then splitting that from the string to give just the path #>
                
           $itemhistory = get-tfschilditem -server $tfsserverobject -item "$itempath"
                
                <# ///////////////////////////////////////
                $itemhsitory will be empty (or 0) if the item doesn't exist in TFS. It should exist unless there is a typo in the path. 
                //////////////////////////////////////////
                #>
                
                if ($itemhistory.count -eq 0)
                  {
                    $ERROR_typos.add("$item") | out-null

                    <# ////////////////////////// 
                    Based on the filename being correct the script scans the list of objects from TFS in the changeset to see if it can find a path with the same filename
                    If it does it adds it to the list of "maybe" answers to the issue. If the filename has a typo then the suggestion will be NONE. 
                    So far experience says most typos are in the path. 
                    ////////////////////////////
                    #>

                    $maybe = $($CS_FILE_LIST | where-object {$_ -match "$((split-path -path "$($itempath)" -leaf).trimend(" "))"})

                        if ($Maybe -eq $null)
                          {
                            if ($cs_file_list -eq $null)
                              {
                                $ERROR_typosMaybe.add("Changeset Invalid unable to determine") | out-null
                              }
                            else
                              {
                                $ERROR_typosMaybe.add("$Maybe") | out-null
                              }
                          }
                        else
                          {
                            $ERROR_typosmaybe.add("Filename has a typo") | out-null
                          }
                  }
                else
                 {
                    $ERROR_badchangeset.add("$item") | out-null
                    $ERROR_badchangesetMaybe.add($(get-tfsitemhistory -HistoryItem "$($itempath)" -server $tfsserverobject).changesetid[0]) | out-null
                 }
          }
            $item=$null
      }
    }
}
<# 
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
Section for writting out all messages to the log
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
#>

<#
////////////////////////////////////////////////////////

Writting out the results if any changeset doesn't exist

////////////////////////////////////////////////////////
#>
 "" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append        

if ($ERROR_CSDoesntExist -ne $null)
{
 "====================================================`n" | Out-File -filepath "$badlog" -Append
 "== ERROR: Changeset doesn't exist ==`n" | Out-File -filepath "$badlog" -Append
 "====================================================`n" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append 

    $HitError = $true

    foreach ($num in $ERROR_CSDoesntExist)
    {
       "Invalid Changeset: $num" | Out-File -filepath "$badlog" -Append
       "   Impacted Files: " | Out-File -filepath "$badlog" -Append
      $tmphldr = $manifest | where-object {$_.ChgSet -eq $num} 
        foreach ($object in $tmphldr)
          {
             "   $($object.path +"\"+$object.file)" | Out-File -filepath "$badlog" -Append
          }
    }
}

<#
////////////////////////////////////////////////////////

Writting out the results of any manifest file with a typo in the path or filename

////////////////////////////////////////////////////////
#>

$item=$null
$count = 0
if ($ERROR_typos -ne $Null)
{
 "" | Out-File -filepath "$badlog" -Append      
 "====================================================`n" | Out-File -filepath "$badlog" -Append
 "== ERROR: Issue with path or filename ==`n" | Out-File -filepath "$badlog" -Append
 "====================================================`n" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append
  $HitError = $true
  While ($count -le ($ERROR_typos.count-1))
  {
    $ERROR_typos[$count] | Out-File -filepath "$badlog" -Append
    "    Closest match in changeset:`n" | Out-File -filepath "$badlog" -Append
    "    $($ERROR_typosMaybe[$count]) `n" | Out-File -filepath "$badlog" -Append
    "" | Out-File -filepath "$badlog" -Append
   $item=$null
   $count++
  }
}

<#
////////////////////////////////////////////////////////

Writting out the results of any file which has the wrong changeset specified. 

////////////////////////////////////////////////////////
#>

$item=$null
$count = 0
if ($ERROR_badchangeset -ne $Null)
{
 "" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append
 "==========================================================`n" | Out-File -filepath "$badlog" -Append
 "== ERROR: The changeset specified in the manifest is incorrect ==`n" | Out-File -filepath "$badlog" -Append
 "==========================================================`n" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append
  $HitError = $true
  While ($count -le ($ERROR_badchangeset.count-1))
  {
    $ERROR_badchangeset[$count] | Out-File -filepath "$badlog" -Append
    "    Last changeset for given path/filename: $($ERROR_badchangesetMaybe[$count])`n" | Out-File -filepath "$badlog" -Append
    "" | Out-File -filepath "$badlog" -Append
   $count++
  }
}

<#
////////////////////////////////////////////////////////
Environment check Errors
///////////////////////////////////////////////////////
#>

if ($EnvInfo_Error -ne $null)
  {
 "" | Out-File -FilePath "$badlog" -append
 "===============================================================`n" | Out-File -FilePath "$badlog" -append
 "==  Error: Environment Check ==`n" | Out-File -FilePath "$badlog" -append
 "===============================================================`n" | Out-File -FilePath "$badlog" -append
 "" | Out-File -filepath "$badlog" -Append
     $HitError = $true
     $EnvInfo_Error | Out-File -FilePath "$badlog" -append
     "" | Out-File -filepath "$badlog" -Append
     "" | Out-File -filepath "$badlog" -Append
     "" | Out-File -filepath "$badlog" -Append
  }

<#
////////////////////////////////////////////////////////

Writting out the results of any objects which have a later changeset than the one specified in the manifest file

////////////////////////////////////////////////////////
#>

$item=$null
$count = 0
if ($ERROR_NotLatestChangeset -ne $Null)
{
 "" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append
 "=======================================================`n" | Out-File -filepath "$badlog" -Append
 "== WARNING: The changeset specified is not the LATEST version ==`n" | Out-File -filepath "$badlog" -Append
 "=======================================================`n" | Out-File -filepath "$badlog" -Append
 "" | Out-File -filepath "$badlog" -Append
  $HitWARNING = $TRUE
  While ($count -le ($ERROR_NotLatestChangeset.count-1))
  {
    $ERROR_NotLatestChangeset[$count] | Out-File -filepath "$badlog" -Append
    "    Latest Changeset for specified path/file: $($ERROR_NotLatestChangesetMaybe[$count])`n" | Out-File -filepath "$badlog" -Append
    "" | Out-File -filepath "$badlog" -Append
   $item=$null
   $count++
  }
}

<#
////////////////////////////////////
Warning: Environment Check
///////////////////////////////////
#>

if ($EnvInfo_Warning -ne $null)
  {
 "" | Out-File -FilePath "$badlog" -append
 "===============================================================`n" | Out-File -FilePath "$badlog" -append
 "==  WARNING: Environment Check ==`n" | Out-File -FilePath "$badlog" -append
 "===============================================================`n" | Out-File -FilePath "$badlog" -append
 "" | Out-File -filepath "$badlog" -Append
    $HitWARNING = $TRUE
    foreach ($tmpvar in $EnvInfo_WARNING)
      {
          $tmpvar | Out-File -FilePath "$badlog" -append
      }
     "" | Out-File -filepath "$badlog" -Append
     "" | Out-File -filepath "$badlog" -Append
     "" | Out-File -filepath "$badlog" -Append
}

#////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
# End of process
End
{
    remove-variable badlog
    remove-variable Manifest
    remove-variable tfsserverURL
    remove-variable tfsserverobject

    Return ($HitError,$HitWARNING)
}
}
<# \\\\\\\\\   END of Verify-HSN_scfiles.ps1 //////////////// #>