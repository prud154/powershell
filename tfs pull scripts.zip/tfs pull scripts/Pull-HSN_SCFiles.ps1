﻿<#
.Synopsis
   Pulls files from HSN TFS 
.DESCRIPTION
   Based on the manifest in the appropriate CR/MR folder this script will go through and pull the files from the source control tool and put the files in the appropriate CR/MR folder. 

   Unless the -dir option is passed to the script it will check the list of objects for duplicate file names. If there are multiple filenames then the files will be pulled to a subdirectory to avoid the conflict. If the -dir option is passed subdirectories will be created by default even if there are no filename conflicts. 

   The -file option will cause the script to prompt for the location of the manifest file to be used for processing. If not provided the script will assume the data is coming directly from a piped object. 

   The -TFSTest option sets the TFS server to the Test environment and is hard coded to use the RE Test collection. 

.EXAMPLE
   Pull-HSN_SCFiles -file
.EXAMPLE
   Pull-HSN_SCFiles -file -dir
.EXAMPLE
   Pull-HSN_SCFiles -file -dir -TFSTest
.EXAMPLE
   Create-HSN_Manifest | Pull-HSN_SCFiles -dir
.INPUTS
   [switch] -file = Lets the program know if a file path/name dialog box needs to be presented to the user. 
   [switch] -dir = Tells the program to create subdirectories when pulling the files from the source control tool regardless if needed. 
   [switch] -TFSTest = Sets the TFS server instance to the Test environment and is hard coded to go to the RE collection. 
.OUTPUTS
   [ascii txt file] RELogs folder in the CR/MR folder by the name of Pull-HSN_SCFiles_<date/time>.log
.NOTES
   Requires that the proper version of the TFS Powertools be installed on the system the script is running from. 
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   Pulls files from a TFS or PVCS source control repository. 
#>
function Pull-HSN_SCFiles
  {
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Medium')]
    [OutputType([String])]
    Param
    (
        # Not working at this time
<#       [Parameter(ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        [psobject]$ManifestObj,
#>

        # Switches the TFS server instance to the Test environment. Hard coded to the RE Test area. 
        [Parameter()]
        [AllowNull()]
        [switch]
        $TFSTest,

        # Causes a file path/name dialog box to be presented for the select of the manifest file to be processed. 
        [Parameter()]
        [AllowNull()]
        [switch]
        $file,

        # Causes a file path/name dialog box to be presented for the select of the manifest file to be processed. 
        [Parameter()]
        [AllowNull()]
        [STRING]
        $manifestloc,

        # Overrides programming and forces subdirectories to be created when moving files to CR/MR folder.
        [Parameter()]
        [AllowNull()]
        [switch]
        $Dir
    )

Begin
    {
        <# 
        Setting TFS Server location .. Used by the various TFS Utilities 
        #>
        
            $TFSServer="http://tfs.hsn.net:8080/tfs/DefaultCollection/" <# Production TFS Instance #>

        <# 
        Detecting if Powertools are installed. If they are not then setting flag to bypass all TFS functionality later on in the script 
        #>

        Write-Host "====================="
        Write-Host "=   Pulling files   ="
        Write-Host "====================="

    }
Process
    {

            <#
            Creating an object which contains the manifest of items to be processed. If the parameter of -file is passed the user will be prompted for the 
            manifest location (in the event there is a significant time delay needed between creating the manifest file and pulling the files from source control tool). 
            Otherwise the program assumes the manifest is coming from a piped object. The most natural assumption the piped object is coming from create-HSN_manifest but can be 
            from any other program as long as it follows the same manifest structure. 
            #>
            if ($file -eq $true)
              {
                 $fileloc = Get-HSN_FileLoc -WindowTitle "Select the Manifest file you wish to process" -InitialDirectory "$global:HSNCRMRLoc"
                 $Manifest = Import-csv -Path "$fileloc"
              }
            Else
              {
                $Manifest = import-csv -path "$Manifestloc"
              }

               Create-HSN_CRMRLoc -CR $Manifest[0].CR -MR $Manifest[0].MR

            <# Setting up Logging location #>
            $log = "$global:HSNCRMRLoc"+"\$($manifest[0].cr)"+"\$($Manifest[0].MR)"+"\RELogs\ProcessLogs\Pull-HSNSCfiles.log"


            if (!(test-path $($log)))
              {
                New-Item -Path "$log" -itemtype File | Out-Null
                 "===============================" | Out-File -FilePath "$log" -Append
                 "==  $(get-date)  ==" | Out-File -FilePath "$log" -Append
                 "===============================" | Out-File -FilePath "$log" -Append
                 "" | Out-File -FilePath "$log" -Append
                 "" | Out-File -FilePath "$log" -Append
              }
            else
              {
                  Move-Item "$Log" -destination "$($Global:HSNCRMRLoc)\$($Manifest[0].CR)\$($Manifest[0].MR)\RELogs\ProcessLogs\$(get-date -uformat %Y.%m.%d-%H.%M.%S)_$($Log.split("\")[-1])" | Out-Null
                  New-Item -Path "$Log" -ItemType file | Out-Null
                 
                 
                 "===============================" | Out-File -FilePath "$log" -Append
                 "==  $(get-date)  ==" | Out-File -FilePath "$log" -Append
                 "===============================" | Out-File -FilePath "$log" -Append
                 "" | Out-File -FilePath "$log" -Append
                 "" | Out-File -FilePath "$log" -Append
              }
        

            if ($env:TFSPowerToolDir -eq $null)
              {
                "The TFS Powertools are not installed on this machine`n" | out-file -FilePath "$log" -append
              }
            else
              {
                try
                 {
                   Add-PSSnapin Microsoft.teamfoundation.powershell -ErrorAction Stop
                 }
               catch
                {
                  [System.Management.Automation.Runspaces.PSSnapInException]
                  "The TFS Powertools are not installed on this machine`n" | out-file -FilePath "$log" -append
                }
             }


            <# If the number of unique filenames is less than the manifest count then some filenames are repeats and directories should be used #>
            if ($dir)
              {
                $dirreq = $true
                "Directories Forced? = $DirReq`n" | Out-File -FilePath "$log" -append
              }
            Else
              {
                if (($($manifest | foreach-object {$_.file} | sort-object -unique).count) -ne ($($manifest | foreach-object {$_.file}).count))
                  {
                    $DirReq = $true
                    "Multiple identical filenames so directories are Required? = $DirReq`n" | Out-File -FilePath "$log" -append
                  }
                Else
                  {
                    $DirReq = $false
                  }
              }
                
             
             "`n" | Out-File -FilePath "$log" -append
             "# of TFS items to be processed = $(($manifest | measure-object).count)`n" | Out-File -FilePath "$log" -append
        
        
             "<########################################################>`n" | Out-File -FilePath "$log" -append
             "<####### Starting the process to pull TFS files #########>`n" | Out-File -FilePath "$log" -append
             "<########################################################>`n" | Out-File -FilePath "$log" -append
             "`n" | Out-File -FilePath "$log" -Append

             "TFS Server = $($TFSServer)`n" | Out-File -FilePath "$log" -Append
             
             <# 
             Getting workspace location for user/workstation combination. $TFSworkspace.folders.localitem for physical location on workstation. 
             Maintained object item in the event we need additional info on the workspace. Otherwise I think we only need the $TFSworkspace.folders.localitem 
             #>
             $TFSworkspace = (get-tfsserver -name $TFSServer | get-tfsworkspace -owner $env:username) | where-object {$_.name -eq $env:Computername}

             if ($TFSworkspace -eq $null)
             {
             "There is no workspace defined to use on this machine. Please setup a workspace and rerun the pull scripts" | Out-File -FilePath "$log" -append
             Start-Sleep 5
             Exit <# If there is no workspace there is no reason to proceed #>
             }
             else
             {
             "Workspace being used = $($TFSWorkspace)`n" | Out-File -FilePath "$log" -append
             }
             <# 
             Changing directories to workspace location. TFS command line commands are location sensitive. 
             If you are in a workspace location then the commands require less information.
             If you aren't in a workspace area, additional parameters are needed if they work at all 
             #>
             set-location $TFSWorkspace.folders.localitem      
        
             "`nStarting location for pulling of files = $($TFSWorkspace.folders.localitem)`n" | Out-File -FilePath "$log" -append
             "`n" | Out-File -FilePath "$log" -append
        
 
             "TFS Paths prepped to be windows paths`n" | Out-File -FilePath "$log" -append
             "`n" | Out-File -FilePath "$log" -append
             "Removing files from workspace to ensure the proper file gets migrated`n" | Out-File -FilePath "$log" -append
            
            <# Removing all files which are slated to be migrated. Given it is very likely the specific files being migrated aren't in your workspace the option of
            -erroraction SilentlyContinue has been enabled to suppress "the bleed on the screen" of non-critical errors. #>
            
            $i=0
            foreach ($tmpvar in $manifest)
             {
               <# 
               Prepping the path from the manifest to be used in path statements for windows 
               #>
               $path = $(".\"+($tmpvar.path).trimstart("'$/").replace("/","\"))

               remove-item -path "$($path+"\"+$($tmpvar.file))" -erroraction SilentlyContinue | Out-Null
             }
        
            <# 
            
             <# Added 10/6/2016 - Modifying process to directly pull the files from TFS based on stated path/changeset instead of pulling everything in the changeset and then cherry picking what we wanted from the changeset. 
             Has been an issue once or twice where a file was in two changesets requested to be migrated but they only wanted one version of the file to be physically migrated
             #>
             
             $manifest | Foreach-object { &"$($GLOBAL:VSIDELocation)tf.exe" get `"$($($_.path).trimend(" ")+"/")$($($_.file).trimend(" ").trimstart(" "))`" /v:$($_.ChgSet) /overwrite }  | Out-File -FilePath "$log" -append


             <# Copying all files in the manifest to the appropriate CR/MR folder #>
             "`n" | Out-File -FilePath "$log" -append
             "#################################################`n" | Out-File -FilePath "$log" -append
             "######## Moving files to the CR/MR folder #######`n" | Out-File -FilePath "$log" -append
             "#################################################`n" | Out-File -FilePath "$log" -append
       
             "`n" | Out-File -FilePath "$log" -append
       
           $PullIssues = $FALSE

           foreach ($tmpvar in $Manifest)                                                                                                                                                                                               
            {
              <# 
              Prepping the path from the manifest to be used in path statements for windows 
              #>
              $path = $(".\"+($tmpvar.path).trimstart("'$/").replace("/","\"))

              if ($dirreq)
                {
                  $dir1 = ($path.split("\"))[-2] <# Getting 2nd to last directory name #>
                  $dir2 = ($path.split("\"))[-1] <# Getting last directory name #>
                  $combodir = "$($dir1)_$($dir2)"
            
                  if (!(test-path "$global:HSNCRMRLoc\$($tmpvar.cr)\$($tmpvar.MR)\$($combodir)"))
                    {
                      new-item -Path "$global:HSNCRMRLoc\$($tmpvar.cr)\$($tmpvar.MR)\$($combodir)" -ItemType Directory | Out-Null
                      "Created dir $($combodir)`n" | Out-File -FilePath "$log" -append
                      start-sleep 2 <# built in pause to ensure dir gets created before files try to write to the dir #>
                    }
            
                  Copy-Item -path "$($($path)+"\"+$($tmpvar.file))" -destination "$($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\$($combodir)\" | out-null
              
                  if (!($?))
                    {
                      "There was an error writing $($tmpvar.filename) to $($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\$($combodir)\ Please see the log for details`n"  | Out-File -FilePath "$log" -append
                      "Error: $($error[0]).exception`n" | out-file -FilePath "$log" -append <# not using tee as I don't want a log of "blood" on the screen #>
                      "`n"  | Out-File -FilePath "$log" -append
                     $PullIssues=$TRUE
                    }
                  Else
                    {
                      "$($tmpvar.file) copied to $($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\$($combodir)\`n" | Out-File -FilePath "$log" -append
                      $updateenverrors = Update-HSNEnvList -MigrateInfo $tmpvar
                   }
                }
             else
                {  <# Need to detect error in case of issues so proper logging can be done #>
                  Copy-Item -path "$(($path)+"\"+$($tmpvar.file))" -destination "$($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\" | Out-Null
                  
                  if (!($?))
                    {
                      "There was an error writing $($tmpvar.file) to $($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\ Please see the log for details`n"  | Out-File -FilePath "$log" -append
                      "Error: $($error[0]).exception`n" | out-file -FilePath "$log" -append <# not using tee as I don't want a log of "blood" on the screen #>
                       "`n"  | Out-File -FilePath "$log" -append
                      $PullIssues=$TRUE
                    }
                  Else
                    {
                      "$($tmpvar.file) copied to $($Global:HSNCRMRLoc)\$($tmpvar.cr)\$($tmpvar.MR)\`n" | Out-File -FilePath "$log" -append
                      $updateenverrors = Update-HSNEnvList -MigrateInfo $tmpvar
                    }
                }
           }
    }
End
    {
         "`n" | Out-File -FilePath "$log" -append
         "==========================================`n" | Out-File -FilePath "$log" -append
         "== Pull-HSN_SCFiles process is complete ==`n" | Out-File -FilePath "$log" -append
         "==========================================`n" | Out-File -FilePath "$log" -append
    
          return ($pullissues,$updateenverrors)

    }
}
<# \\\\\\\\\   END of Pull-HSN_scfile.ps1 //////////////// #>