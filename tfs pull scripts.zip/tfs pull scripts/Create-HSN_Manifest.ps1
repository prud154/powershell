﻿<#
.Synopsis
   Creates manifest file in preperation to validate source control and ultimately migration itself
.DESCRIPTION
   Creates a manifest file (for later review or processing) and object (for the pipeline) in preperation for source control verifications as well as ultimately the migration itself. 
   
   At this time only one file is allowed to be passed to the process. We will be working on an enhancement to handle multiple files at once. 
.EXAMPLE
   Create-HSN_Manifest -path <[string] path to migration file>
.INPUTS
   [String] value indicating where to find the migration.txt file
.OUTPUTS
   [object] Listing of all items to be deployed
   [XML and CSV File] Listing of all the items to be deployed (the team will decide later which format is preferred)
   [string] Copy of supporting migration file moved to cr/mr folder
.NOTES
   Converts the typical migration.txt file into a file with the following basic format
   CR    MR     <source control path>    <filename>   <version/changeset>
   1234  12345  $/clic oms/reporting/... example.rpt  1234
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   Takes the typical migration.txt file and converts into a xml and excel manifest file for further processing
#>
function Create-HSN_Manifest
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Medium')]
    [OutputType([String])]
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   ValueFromRemainingArguments=$false, 
                   Position=0
                  )]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [string[]]$path
    )

    Begin
    {
    write-host "========================="
    Write-Host "==  Creating Manifest  =="
    write-host "========================="
    }
    Process
    {
      $migrationfile = get-content -path "$path"
      $CR=$migrationfile[0]

      if ($migrationfile[1] -match "rollback")
        {
          $MR = ($migrationfile[1].split("-"))[0]
          $MigType = "Rollback"
        }
      elseif ($migrationfile[1] -match "redeploy")
        {
          $MR = ($migrationfile[1].split("-"))[0]
          $MigType = "Redeploy"
        }
      else
        {
          $MR = $MigrationFile[1]
          $MigType = "Normal"
        }

      <# FINAL FILE Location/Name #>
      $FinalFileCSV=$($Global:HSNCRMRLoc+"\"+$CR+"\"+$MR+"\"+$CR+"_"+$MR+"_Manifest.csv")
           
      <# Creating CR and MR folders if they don't already exist #>
      Create-HSN_CRMRLoc -cr $CR -mr $MR

      <# Detecting if a CSV manifest file already exists and if so renaming it so a new one can be written #>
      if (test-path "$FinalFileCSV")
        {
          Move-item "$FinalFileCSV" -destination "$($Global:HSNCRMRLoc)\$($CR)\$($MR)\RELogs\OldLogs\$($CR)_$($MR)_Manifest_$(get-date -uformat %Y.%m.%d-%H.%M.%S).csv" | Out-Null
          new-item -Path "$FinalFileCSV" -ItemType file | Out-Null
        }

      $manifest = @()

      $migrationfile = get-content -path "$path"
      $TrgtEnv="$($migrationfile[2].replace(",",";"))"

      Foreach ($line in $migrationfile[3..$migrationfile.length])
        {
          $ChgSet=$(($line.split(" "))[-1]).trimend(" ") <# Getting Version number off of the line #>
          $temppath=($line.trimend("$ChgSet")).trimend(" ") <# creating tempvariable to split the path from the filename #>
          $File=(($temppath.split("/"))[-1]) <# Pulling the filename off of the line #>
          $Path=($temppath.trimend("$file")).trimend("/") <# Pulling the path statement off of the line #>
          <# Determine the source control type based on the syntax differences between PVCS and TFS for the Source control path #>
          If ($path.startswith("//"))
            {
              $SCType="PVCS"
              $Path = $path.replace("/","\")
            }
          Else
            {
              $SCType="TFS"
              $adddata = new-object -typename PSObject -property @{
                 CR = "$CR"
                 MR = "$MR"
                 File = "$File"
                 Path = "$Path"
                 ChgSet = "$ChgSet"
                 TrgtEnv = "$TrgtEnv"
                 SCType = "$SCType"
                 DeployType = "$MigType"
                }
           $manifest = $manifest + $adddata
           remove-variable file
           remove-variable path
           remove-variable ChgSet
           remove-variable sctype
           remove-variable adddata 
          }
        }  
    $manifest | select-object -property 'CR','MR','File','ChgSet','TrgtEnv','SCType','DeployType','Path' | export-csv -Path "$FinalFileCSV" -NoTypeInformation
    }
    End
    {
      
    }
}