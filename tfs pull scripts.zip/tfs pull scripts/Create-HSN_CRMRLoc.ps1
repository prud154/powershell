﻿<#
.Synopsis
   Checks and if it doesn't exist creates the CR, MR, and RELogs folders
.DESCRIPTION
   This scripts main purpose is to initiatize the CR/MR folder for upcoming migrations/verifications steps. The CR and MR is pulled from the default migration.txt file. 

   Takes a parameter of -path which is the path and filename of the migration.txt file containing the CR/MR information. If the correct filename is missing from the path it will prompt as if no path was provided. 
.EXAMPLE
   Create-HSN_CRMRLoc

   This will prompt the user for the location of the migration.txt file to use for the CR/MR information
.EXAMPLE
   Create-HSN_CRMRLoc -path "I:\cm share\release engineers\work\notepads\villinest_migration.txt"

    This will automatically load the information in the file specified and create the CR/MR folders which correponds to the information in the file. 
.INPUTS
   -path = Path/File for the migration.txt file needing
.OUTPUTS
   The only output is the creation of the CR/MR/RELogs folder at the standard location. 
.NOTES
   General notes
.COMPONENT
   The component this cmdlet belongs to
.ROLE
   The role this cmdlet belongs to
.FUNCTIONALITY
   The functionality that best describes this cmdlet
#>
function Create-HSN_CRMRLoc
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$false,
                  ConfirmImpact='Low')]
    [OutputType([String])]
    Param
    (
        # CR Number
        [Parameter(ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        $CR,

        # MR Number 
        [Parameter(ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true)]
        $MR
    )

    Begin
    {
    }
    Process
    {

    if (!(test-path "$Global:HSNCRMRLoc\$CR"))
        {
            New-item -path "$Global:HSNCRMRLoc\$CR" -itemtype directory | Out-null
            start-sleep -Seconds 3
        }
     if (!(test-path "$Global:HSNCRMRLoc\$CR\$MR"))
        {
           New-item -path "$Global:HSNCRMRLoc\$CR\$MR" -itemtype directory | Out-null
        }
        
    if (!(test-path "$Global:HSNCRMRLoc\$CR\$MR\RELogs"))
        {
          New-item -path "$Global:HSNCRMRLoc\$CR\$MR\RELogs" -itemtype directory | Out-null
        }
    
    if (!(test-path "$Global:HSNCRMRLoc\$CR\$MR\RELogs\oldLogs"))
        {
          New-item -path "$Global:HSNCRMRLoc\$CR\$MR\RELogs\oldLogs" -itemtype directory | Out-null
        }
    
    if (!(test-path "$Global:HSNCRMRLoc\$CR\$MR\RELogs\ProcessLogs"))
        {
          New-item -path "$Global:HSNCRMRLoc\$CR\$MR\RELogs\ProcessLogs" -itemtype directory | Out-null
        }
    
    }
    End
    {
    }
}