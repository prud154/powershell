﻿<#
.Synopsis
   Gets path and filename via pop-up window
.DESCRIPTION
   Gets path and filename of one or more files via a pop-up window. If multiple files are needed they must be in the same path location. 
.EXAMPLE
   Get-HSN_FileLoc -WindowTitle "Select file(s) which are migration.txt formatted files" -InitialDirectory "C:\" -allowmultiselect
.EXAMPLE
   Get-HSN_FileLoc -WindowTitle "Select file(s) which need to be processed" -InitialDirectory "C:\Work"

#>
function Get-HSN_FileLoc
{
    [CmdletBinding (SupportsShouldProcess=$true, ConfirmImpact='low')]
    Param
    (
        [Parameter(
        Mandatory=$true,
        ValueFromPipeline=$true,
        HelpMessage="A title for the popup window to indicate the type of file you are looking for")]
        [ValidateNotNullOrEmpty()]
        [string]$WindowTitle,

        [Parameter(HelpMessage='Directory the pop-up window starts in to select files from. UNC paths not supported by default')]
        [string]$InitialDirectory,
        
<#      Will enhance this section in the near future to allow the user to pass the arguments of (all, txt) as a filter. Then in the program I will format the filter option as the main application needs it. 
        [Parameter(HelpMessage='Directory the pop-up window starts in to select files from. UNC paths not supported by default')]
        [string]$InitialDirectory,

#>
        [Parameter(HelpMessage='True/False which allows multiple files to be selected')]
        [switch]$AllowMultiSelect
        )
       
    Begin
    {
    Add-Type -AssemblyName System.Windows.Forms
    $Filter="All Files (*.*)|*.*"
    }
    Process
    {
        $openFileDialog = New-Object System.Windows.Forms.OpenFileDialog
        $openFileDialog.Title = $WindowTitle
    
        if (![string]::IsNullOrWhiteSpace($InitialDirectory)) 
            { 
                $openFileDialog.InitialDirectory = $InitialDirectory
            }
        $openFileDialog.Filter = $Filter
    
        if ($AllowMultiSelect) 
            { 
                $openFileDialog.MultiSelect = $true 
            }
        $openFileDialog.ShowHelp = $true    # Without this line the ShowDialog() function may hang depending on system configuration and running from console vs. ISE.
        $openFileDialog.ShowDialog() > $null

    }
    End
    {
            if ($AllowMultiSelect) 
            { 
                return $openFileDialog.FileNames 
            } 
        else 
            { 
                return $openFileDialog.Filename
            }
    }
}