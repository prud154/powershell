﻿<#
.Synopsis
   Allows for a pop-up allowing the user to choose one option over another. 
.DESCRIPTION
   Allows for a pop-up (only two answers possible) allowing the user to choose one option over another. 
   Takes four parameters 
   1) Caption <optional> (brief title for the choice being presented)
   2) Description (lets the user know overall what is being asked)
   3) Option1 (1st option to pick from)
   4) Option2 (2nd option to pick from). 
.EXAMPLE
   pick-HSN_option -title "Delete all files" -option1 yes -option2 No
.EXAMPLE
   pick-HSN_option -title "What type of ice cream do you like?" -option1 Chocoloate -option2 Vanilla
.EXAMPLE
   pick-HSN_option -caption "Delete Files" -title "Do you want to delete all the files?" -option1 "Yes Way" -Option2 "No Way"
.INPUTS
   Caption = Very short description of what is being asked <optional>
   Description = Gives the users an overall idea of what is being asked to choose from
   Option1 = 1st option to pick from
   Option2 = 2nd option to pick from
.OUTPUTS
   [String] value representing the option which was chosen by the user. 0 will be returned for the 1st option passed and a 1 will be returned if the 2nd option is selected. 
.NOTES
   This cmdlet only allows two options to be displayed. More options will be added in the future to cover (yes to all, No to all, and cancel)
.COMPONENT
   
.ROLE
   
.FUNCTIONALITY
   Allows for a pop-up allowing the user to choose one option over another.
#>
Function pick-HSN_option
{
    [CmdletBinding(SupportsShouldProcess=$true, 
                  PositionalBinding=$true,
                  ConfirmImpact='low')]
    [OutputType([String])]
    Param
    (
        [Parameter(
        Mandatory=$false,
        HelpMessage="Very brief (usually 2 to 3 words) outlining what is being done overall (ex. Delete Files, Favorite ice cream)"
        )] 
        [STRING]$Caption,

        # Title indicating what is being requested
        [Parameter(
        Mandatory=$true,
        HelpMessage="The question/choice you are asking the user to pick the options for. (ex. Do you wish to delete all the files in the current directory, What is your favorite type of ice cream?)"
        )] 
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("Title")] 
        [STRING]$Description,
       
        # 1st of 2 available choices for user to pick from
        [Parameter(
        Mandatory=$true,
        HelpMessage="This is the 1st (of 2) the user has to pick from. (ex. Yes, Chocolate)")]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("Choice1")] 
        [STRING]$Option1,

        # 2nd of 2 available choices for user to pick from
        [Parameter(
        Mandatory=$true,
        HelpMessage="This is the 2nd (of 2) option the user has to pick from. (ex. No, Vanilla)")]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("Choice2")]
        [STRING]$Option2
    )
    Begin
    {
    Add-Type -AssemblyName System.Windows.Forms
    }
    Process
    {
         $Item1 = new-Object System.Management.Automation.Host.ChoiceDescription "&0 - $Option1","Select 0 for $($Option1)"
         $Item2 = new-Object System.Management.Automation.Host.ChoiceDescription "&1 - $Option2","Select 1 for $($Option2)"
         $Choices = [System.Management.Automation.Host.ChoiceDescription[]]($Item1,$Item2)
         $retval = $host.UI.PromptForChoice($Caption,$Description,$Choices,0)
    }
    End
    {
    return $retval
    }
}