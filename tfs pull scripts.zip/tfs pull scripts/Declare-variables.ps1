﻿$GLOBAL:HSNCRMRLoc="i:\cm share\release engineers\work"
$GLOBAL:HSNMigrationsLoc='I:\cm share\release engineers\work\notepads'
$GLOBAL:HSNEnvLoc="i:\cm share\release engineers\TFSEnvInfo"
if ([environment]::Is64BitProcess)
{
    $GLOBAL:VSIDELocation=(((get-childitem -path $("c:\program files (x86)\Microsoft Visual Studio*") -Directory)[-1].fullname)+"\common7\ide\")
}
else
{
    $GLOBAL:VSIDELocation=(((get-childitem -path $("c:\program files\Microsoft Visual Studio*") -Directory)[-1].fullname)+"\common7\ide\")
}

