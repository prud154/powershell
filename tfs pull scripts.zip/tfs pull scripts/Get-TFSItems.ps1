﻿function Clean ($MigrationTXTpath)
  {
    <# Clean and create manifest script #>
    $CleanIssues = Clean-HSN_MigrationFile -path "$MigrationTXTpath"
    
    $CleanErrors = $CleanIssues[0]
    $CleanWarnings = $CleanIssues[1]
    $MigrationTXTPath = $CleanIssues[2] <# resetting MigrationTXTPath to be the migration.txt in the CR/MR folder #>

    if (($CleanErrors -ne $TRUE) -and ($CleanWarnings -ne $TRUE)) <# In the clean scripts the values will be null unless the conditions occur. So the answers are either $TRUE or $NULL #>
      {
        CreateManifest -migrationTXTpath "$($MigrationTXTPath)"
      }
    Elseif ($CleanWarnings -ne $TRUE)
      {
        Write-Host "********************************"
        Write-Host ""
        Write-Host "Warning"
        Write-host ""
        Write-Host "********************************"
        Write-Host ""
        Write-host "Warnings were generated during the cleaning of the migration.txt."
        Write-Host "Please review the log file and choose whether to proceed."
        invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
        $proceed = pick-HSN_option -Caption "Proceed?" -Description "Warnings during verification. Proceed?" -Option1 "Yes" -Option2 "No"

        if ($proceed -eq 0)
          {
            CreateManifest -MigrationTXTpath "$($MigrationTXTPath)"
          }
        elseif ($proceed -eq 1)
          {
            Write-Host "There were Warnings during the cleaning of the Migration.txt and you have chosen not to proceed"
          }
       }
     Else
       {
         Write-Host "There were critical errors cleaning the migration.txt."
         Write-Host "The Log can be found at $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs") "
         Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
       }
  }

Function CreateManifest ($MigrationTXTpath)
  {

  Create-HSN_Manifest -path "$MigrationTXTPath"

  if (test-path -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))")
    {
      <# Verify Manifest script #>
      Verify -manifestpath "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))"
    }
  else
    {
      Write-Host "There were errors creating the manifest file."
      Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")"
    }
  }

Function Verify ($ManifestPath)
  {
    $VerifyIssues = Verify-HSN_SCFiles -manifestloc "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))"
    

    $VerifyErrors = $VerifyIssues[0]
    $VerifyWarnings = $VerifyIssues[1]

    if (($VerifyErrors -ne $TRUE) -and ($VerifyWarnings -ne $TRUE)) <# In the clean scripts the values will be null unless the conditions occur. So the answers are either $TRUE or $NULL #>
      {
        PullandTrack -ManifestPath "$ManifestPath"
      }
    Elseif ($verifyWarnings)
      {
        Write-Host "Warnings were generated during the Verification of the manifest file. Please review the warnings in the log file and choose whether to proceed."
        invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
        $proceed = pick-HSN_option -Caption "Proceed?" -Description "Warnings during verification. Proceed?" -Option1 "Yes" -Option2 "No"

        if ($proceed -eq 0)
          {
            PullandTrack -ManifestPath "$ManifestPath"
          }
        elseif ($proceed -eq 1)
          {
            Write-Host "There were Warnings during the verification of the manifest file and you have chosen not to proceed."
          }
       }
     Else
       {
         Write-Host "There were critical errors while verifying the manifest file! The Log can be found at $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs") "
         Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
       }
  }

Function PullandTrack ($ManifestPath)  
  {
    $PullIssues = Pull-HSN_SCFiles -manifestloc "$ManifestPath"

    $PullErrors = $PullIssues[0]
    $UpdateErrors = $PullIssues[1]


    if (($Pullerrors) -and ($UpdateErrors))
      {
            Write-host "There were issues Pulling files from TFS and updating Environment information. Please review the logs!"
            Write-Host "Logs located at: $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")"
            invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")"
      }
    elseif ($Pullerrors)
      {
            Write-Host "There were issues Pulling files from TFS. Please review the logs!"
            Write-Host "Logs located at: $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")."
            invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")"
      }
    elseif ($UpdateErrors)
      {
            Write-Host "There were issues Updating Environment Information. Please review the logs!"
            Write-Host "Logs located at: $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")."
            invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs\ProcessLogs")"                       
      }
    else
      {
            Write-host "Files are ready for migration. Files can be found at : $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR)"
            invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR)"
           <# GenerateEmail -CR $GLOBAL:CR -MR $GLOBAL:MR #>
      }
  }

<# Team decided to not perform this activity at this time. Code left here in the event we need it in the future
Function GenerateEmail ()
  {
    $manifest = import-csv -path "$($GLOBAL:HSNCRMRLoc + "\" + $GLOBAL:CR + "\" + $GLOBAL:MR + "\" + $($GLOBAL:CR + "_" + $GLOBAL:MR + "_Manifest.csv"))"
    $log = "$($GLOBAL:HSNCRMRLoc + "\" + $GLOBAL:CR + "\" + $GLOBAL:MR + "\RELogs\Pull-HSNSCFiles.log")"

    $mailbody = [System.Collections.ArrayList]@()
    $mailbody.add("The following migration has been completed. Please Validate!`n`n")
    $manifest | foreach {"$/$($_.path)\$($_.file) $($_.chgset) `n"} | foreach {$mailbody.add($_)} | out-null

    $mail = (New-Object -comObject Outlook.Application).CreateItem(0)
    $mail.htmlbody
    $mail.cc = "ReleaseEngineers@hsn.net; <DBA Group>"
    $mail.Subject = "CR$($GLOBAL:CR) - MR$($GLOBAL:MR) - Complete - $($manifest[0].TrgtEnv) (U/S) (A) (E - IN#####) Capital Project: ######/Expense"
    $mail.Body = "$mailbody"
    $mail.attachments.add($log) | out-null
    $mail.save()
    ($mail.GetInspector).Display()
  }
#>


<#
=======================================================================
==========                   Main Code Segment           ==============
=======================================================================
#>

Write-Host "Loading RE PS Tools"
$SCRIPTLOC="\\filer01\miscommon$\cm share\release engineers\new re setup\powershellscripts\retools"

Get-ChildItem -Path "$SCRIPTLOC\*.ps1" | ForEach-Object{.$_}
if ($?)
  {
     Write-Host "RE Powershell Tools Loaded.. Proceeding with migration"

     $MigrationTXTpath = Get-HSN_FileLoc -WindowTitle "Select Migration.txt to process" -InitialDirectory "$GLOBAL:HSNMigrationsLoc"

     $tmpvar = get-content -Path "$MigrationTXTPath"
    
     $GLOBAL:CR = $tmpvar[0]
    
     $GLOBAL:MR = $tmpvar[1]
    
     Create-HSN_CRMRLoc -CR $GLOBAL:CR -MR $GLOBAL:MR
     Clean -MigrationTXTpath "$MigrationTXTpath"
   }
else
  {
    Write-Host "Something went way wrong! There were issues loading the RE Powershell Scripts. Exiting"
  }