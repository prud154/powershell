﻿function Clean ($MigrationTXTpath)
  {
    <# Clean and create manifest script #>
    $CleanIssues = Clean-HSN_MigrationFile -path "$MigrationTXTpath"
    
    $CleanErrors = $CleanIssues[0]
    $CleanWarnings = $CleanIssues[1]
    $MigrationTXTPath = $CleanIssues[2] <# resetting MigrationTXTPath to be the migration.txt in the CR/MR folder #>

    if (($CleanErrors -ne $TRUE) -and ($CleanWarnings -ne $TRUE)) <# In the clean scripts the values will be null unless the conditions occur. So the answers are either $TRUE or $NULL #>
      {
        CreateManifest -migrationTXTpath "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($env:username+"_Migration.txt"))"
      }
    Elseif ($CleanWarnings -ne $TRUE)
      {
        Write-Host "********************************"
        Write-Host ""
        Write-Host "Warning..Will Robinson...Warning"
        Write-host ""
        Write-Host "********************************"
        Write-Host ""
        Write-host "Warnings were generated during the cleaning of the migration.txt."
        Write-Host "Please review the log file and choose whether to proceed."
        invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
        $proceed = pick-HSN_option -Caption "Proceed?" -Description "Warnings during verification. Proceed?" -Option1 "Yes" -Option2 "No"

        if ($proceed -eq 0)
          {
            CreateManifest -MigrationTXTpath "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($env:username+"_Migration.txt"))"
          }
        elseif ($proceed -eq 1)
          {
            Write-Host "There were Warnings during the cleaning of the Migration.txt and you have chosen not to proceed"
          }
       }
     Else
       {
         Write-Host "There were critical errors cleaning the migration.txt. Come back and visit once you have cleaned your room!"
         Write-Host "The Log can be found at $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs") "
         Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
       }
  }

Function CreateManifest ($MigrationTXTpath)
  {
  Create-HSN_Manifest -path "$MigrationTXTPath"

  if (test-path -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))")
    {
      <# Verify Manifest script #>
      Verify -manifestpath "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))" -crreview
    }
  else
    {
      Write-Host "There were errors creating the manifest file. And no I don't know why!"
      Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
    }
  }

Function Verify ($ManifestPath)
  {
    $VerifyIssues = Verify-HSN_SCFiles -manifestloc "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\"+$($GLOBAL:CR+"_"+$GLOBAL:MR+"_Manifest.csv"))"
    

    $VerifyErrors = $VerifyIssues[0]
    $VerifyWarnings = $VerifyIssues[1]

    if (($VerifyErrors -ne $TRUE) -and ($VerifyWarnings -ne $TRUE)) <# In the clean scripts the values will be null unless the conditions occur. So the answers are either $TRUE or $NULL #>
      {
        Write-Host "No warnings or errors were detected during verification. Opening Logs location for convenience"
        Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
      }
    Elseif ($verifyWarnings)
      {
        Write-Host "Warnings were generated during the Verification of the manifest file. Please review the warnings in the log file and choose whether to proceed."
        invoke-item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
       }
     Else
       {
         Write-Host "There were critical errors while verifying the manifest file! The Log can be found at $($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs") "
         Invoke-Item -Path "$($GLOBAL:HSNCRMRLoc+"\"+$GLOBAL:CR+"\"+$GLOBAL:MR+"\RELogs")"
       }
  }

<#
=======================================================================
==========                   Main Code Segment           ==============
=======================================================================
#>

Write-Host "Loading RE PS Tools"
$SCRIPTLOC="\\filer01\miscommon$\cm share\release engineers\new re setup\powershellscripts\retools"
Get-ChildItem "${SCRIPTLOC}\*.ps1" | ForEach-Object{.$_} 
if ($?)
  {
    Write-Host "RE Powershell Tools Loaded.. Proceeding with migration"

    $MigrationTXTpath = Get-HSN_FileLoc -WindowTitle "Select Migration.txt to process" -InitialDirectory "$GLOBAL:HSNMigrationsLoc"
    
    $tmpvar = get-content -Path "$MigrationTXTPath"
    
    $GLOBAL:CR = $tmpvar[0]
    
    if (($tmpvar[1] -match "rollback") -or ($tmpvar[1] -match "redeploy"))
      {
        $GLOBAL:MR = ($tmpvar[1].split("-"))[0]
      }
    else
      {
        $GLOBAL:MR = $tmpvar[1]
      }
     
     Create-HSN_CRMRLoc -CR $GLOBAL:CR -MR $GLOBAL:MR

     Clean -MigrationTXTpath "$MigrationTXTpath"
   }
else
  {
    Write-Host "Something went way wrong! There were issues loading the RE Powershell Scripts. Exiting"
  }